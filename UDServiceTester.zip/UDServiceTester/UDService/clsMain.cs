﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System;
using System.IO;
using System.Security.Permissions;
using System.Diagnostics;

namespace UDService
{
    public class clsMain
    {

        string WatcherFilter = "";
        string WatcherFolder = "";
        EventLog MyEventLog = null;
        string EvtLogName = "";
        string EvtLogSource = "";
        bool LogExists = false;
        bool StopService = false;


        private void GetSettings()
        {
            WatcherFilter = "*.txt";
            WatcherFolder = "C:\\";
            EvtLogName = "UDSL";
            EvtLogSource = "UDService";
        }

        public void StartExecution()
        {
            GetSettings();
            CheckCreateLog();
            StartWatcher();
        }

        private void CheckCreateLog()
        {
            try
            {


                if (System.Diagnostics.EventLog.Exists(EvtLogName) == false)
                {
                    System.Diagnostics.EventLog.CreateEventSource(EvtLogSource, EvtLogName);
                }

                if (System.Diagnostics.EventLog.SourceExists(EvtLogSource) == false)
                {
                    System.Diagnostics.EventLog.CreateEventSource(EvtLogSource, EvtLogName);
                }

                MyEventLog = new EventLog(EvtLogName);
                MyEventLog.Source = EvtLogSource;
                LogExists = true;
            }
            catch (System.Exception)
            {

                // Just catch it
            }

        }

        private void StartWatcher()
        {
            try
            {

                FileSystemWatcher UDWatcher = new FileSystemWatcher();
                UDWatcher.Path = WatcherFolder;
                UDWatcher.Filter = WatcherFilter;

                UDWatcher.Changed += new FileSystemEventHandler(OnChanged);
                UDWatcher.Created += new FileSystemEventHandler(OnCreated);
                UDWatcher.Deleted += new FileSystemEventHandler(OnDeleted);
                UDWatcher.Renamed += new RenamedEventHandler(OnRenamed);

                // Begin watching.
                UDWatcher.EnableRaisingEvents = true;
                RecordMsg("Watcher started! - " + DateTime.Now, false);

            }
            catch (Exception e)
            {
                // record Exception To Log
                if (LogExists == true)
                {
                    RecordMsg(e.Message, true);
                }
            }
        }

        private void OnChanged(object source, FileSystemEventArgs e)
        {
            RecordMsg("File changed.", false);
        }

        private void OnCreated(object source, FileSystemEventArgs e)
        {
            RecordMsg("File created.", false);
        }

        private void OnDeleted(object source, FileSystemEventArgs e)
        {
            RecordMsg("File deleted.", false);
        }

        private void OnRenamed(object source, RenamedEventArgs e)
        {
            RecordMsg("File renamed.", false);
        }

        public void RecordMsg(string Msg, bool IsError)
        {
            if (LogExists == true)
            {
                try
                {
                    switch (IsError)
                    {
                        case true:
                            MyEventLog.WriteEntry(Msg, EventLogEntryType.Error);
                            break;

                        case false:
                            MyEventLog.WriteEntry(Msg, EventLogEntryType.Information);
                            break;
                    }
                }
                catch (System.Exception)
                {

                    // Just Catch it
                }
            }
        }
    }
}
