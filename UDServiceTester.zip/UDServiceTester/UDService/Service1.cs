﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;

namespace UDService
{
    public partial class Service1 : ServiceBase
    {
        public clsMain cMain = new clsMain();

        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            cMain.StartExecution();
        }

        protected override void OnStop()
        {
            cMain.RecordMsg("UDService stopped! - " + DateTime.Now, false);
        }
    }
}
