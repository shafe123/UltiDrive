﻿namespace UDServiceTester
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnStartTesting = new System.Windows.Forms.Button();
            this.btnDeleteEvtLog = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnStartTesting
            // 
            this.btnStartTesting.Location = new System.Drawing.Point(12, 12);
            this.btnStartTesting.Name = "btnStartTesting";
            this.btnStartTesting.Size = new System.Drawing.Size(107, 23);
            this.btnStartTesting.TabIndex = 0;
            this.btnStartTesting.Text = "Start Testing";
            this.btnStartTesting.UseVisualStyleBackColor = true;
            this.btnStartTesting.Click += new System.EventHandler(this.btnStartTesting_Click);
            // 
            // btnDeleteEvtLog
            // 
            this.btnDeleteEvtLog.Location = new System.Drawing.Point(12, 41);
            this.btnDeleteEvtLog.Name = "btnDeleteEvtLog";
            this.btnDeleteEvtLog.Size = new System.Drawing.Size(107, 23);
            this.btnDeleteEvtLog.TabIndex = 1;
            this.btnDeleteEvtLog.Text = "Delete Event Log";
            this.btnDeleteEvtLog.UseVisualStyleBackColor = true;
            this.btnDeleteEvtLog.Click += new System.EventHandler(this.btnDeleteEvtLog_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(124, 81);
            this.Controls.Add(this.btnDeleteEvtLog);
            this.Controls.Add(this.btnStartTesting);
            this.Name = "Form1";
            this.Text = "Test";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnStartTesting;
        private System.Windows.Forms.Button btnDeleteEvtLog;
    }
}

