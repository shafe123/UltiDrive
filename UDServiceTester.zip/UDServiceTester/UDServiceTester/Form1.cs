﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System;
using System.IO;
using System.Security.Permissions;




namespace UDServiceTester
{
    public partial class Form1 : Form
    {
        public clsMain cMain = new clsMain();

        public Form1()
        {
            InitializeComponent();
        }

        private void btnStartTesting_Click(object sender, EventArgs e)
        {
            cMain.StartExecution();
        }

        private void btnDeleteEvtLog_Click(object sender, EventArgs e)
        {
            cMain.GetSettings();
            try
            {
              System.Diagnostics.EventLog.DeleteEventSource(cMain.EvtLogSource);
            }
            catch (Exception exc)
            {

                MessageBox.Show(exc .Message);
            }
           
        }
    }
}
